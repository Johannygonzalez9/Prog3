import java.util.Random;

public class Cajero extends Thread {
    private Boveda boveda;
    private int transacciones = 0;
    private Random random = new Random();

    public Cajero(String nombre, Boveda boveda) {
        super(nombre);
        this.boveda = boveda;
    }

    @Override
    public void run() {
        int clientes = random.nextInt(3) + 3; // 3 a 5 clientes

        for (int i = 0; i < clientes; i++) {
            double monto = 500 + (1500 * random.nextDouble());

            synchronized (boveda) {
                if (boveda.retirar(monto)) {
                    transacciones++;
                    System.out.println(getName() + " retiró $" + String.format("%.2f", monto));
                } else {
                    System.out.println(getName() + " intentó retirar $" + String.format("%.2f", monto) + " pero no hay saldo suficiente.");
                }
            }

            try {
                Thread.sleep((random.nextInt(3) + 1) * 1000);
            } catch (InterruptedException e) {
                System.out.println(getName() + " fue interrumpido.");
            }
        }
    }

    public int getTransacciones() {
        return transacciones;
    }
}
