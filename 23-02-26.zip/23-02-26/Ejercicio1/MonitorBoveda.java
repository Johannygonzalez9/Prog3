public class MonitorBoveda extends Thread {
    private Boveda boveda;

    public MonitorBoveda(Boveda boveda) {
        this.boveda = boveda;
        setDaemon(true);
    }

    @Override
    public void run() {
        while (true) {
            System.out.println("Saldo actual de la bóveda: $" + String.format("%.2f", boveda.getSaldo()));
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}
