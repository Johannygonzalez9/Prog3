public class MainEjercicio1 {
    public static void main(String[] args) {
        Boveda boveda = new Boveda();

        Cajero cajero1 = new Cajero("Cajero 1", boveda);
        Cajero cajero2 = new Cajero("Cajero 2", boveda);
        Cajero cajero3 = new Cajero("Cajero 3", boveda);

        MonitorBoveda monitor = new MonitorBoveda(boveda);

        monitor.start();
        cajero1.start();
        cajero2.start();
        cajero3.start();

        try {
            cajero1.join();
            cajero2.join();
            cajero3.join();
        } catch (InterruptedException e) {
            System.out.println("Error al esperar los hilos.");
        }

        System.out.println("\n===== RESUMEN FINAL =====");
        System.out.println("Transacciones Cajero 1: " + cajero1.getTransacciones());
        System.out.println("Transacciones Cajero 2: " + cajero2.getTransacciones());
        System.out.println("Transacciones Cajero 3: " + cajero3.getTransacciones());
        System.out.println("Saldo final de la bóveda: $" + String.format("%.2f", boveda.getSaldo()));
    }
}
