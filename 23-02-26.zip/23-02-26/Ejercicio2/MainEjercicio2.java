import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainEjercicio2 {
    private static final String ARCHIVO = "estudiantes.dat";
    private static List<Estudiante> estudiantes = new ArrayList<>();

    public static void main(String[] args) {
        cargarDatos();

        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n1. Agregar estudiante");
            System.out.println("2. Buscar estudiante");
            System.out.println("3. Listar estudiantes");
            System.out.println("4. Salir");
            System.out.print("Seleccione opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    agregarEstudiante(sc);
                    break;
                case 2:
                    buscarEstudiante(sc);
                    break;
                case 3:
                    listarEstudiantes();
                    break;
                case 4:
                    guardarDatos();
                    System.out.println("Datos guardados correctamente.");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 4);

        sc.close();
    }

    private static void agregarEstudiante(Scanner sc) {
        try {
            System.out.print("Nombre: ");
            String nombre = sc.nextLine();
            System.out.print("Matrícula: ");
            String matricula = sc.nextLine();
            System.out.print("Promedio: ");
            double promedio = sc.nextDouble();
            sc.nextLine();

            estudiantes.add(new Estudiante(nombre, matricula, promedio));
            System.out.println("Estudiante agregado correctamente.");
        } catch (Exception e) {
            System.out.println("Error al agregar estudiante: " + e.getMessage());
        }
    }

    private static void buscarEstudiante(Scanner sc) {
        try (RandomAccessFile raf = new RandomAccessFile(ARCHIVO, "r")) {
            System.out.print("Ingrese matrícula a buscar: ");
            String matricula = sc.nextLine();

            for (Estudiante e : estudiantes) {
                if (e.getMatricula().equals(matricula)) {
                    System.out.println("Estudiante encontrado: " + e);
                    return;
                }
            }
            System.out.println("Estudiante no encontrado.");
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado.");
        } catch (IOException e) {
            System.out.println("Error al buscar estudiante: " + e.getMessage());
        }
    }

    private static void listarEstudiantes() {
        if (estudiantes.isEmpty()) {
            System.out.println("No hay estudiantes registrados.");
        } else {
            for (Estudiante e : estudiantes) {
                System.out.println(e);
            }
        }
    }

    private static void cargarDatos() {
        File file = new File(ARCHIVO);
        if (!file.exists()) {
            return;
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            estudiantes = (List<Estudiante>) ois.readObject();
            System.out.println("Datos cargados correctamente.");
        } catch (Exception e) {
            System.out.println("Error al cargar datos: " + e.getMessage());
        }
    }

    private static void guardarDatos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO))) {
            oos.writeObject(estudiantes);
        } catch (IOException e) {
            System.out.println("Error al guardar datos: " + e.getMessage());
        }
    }
}
