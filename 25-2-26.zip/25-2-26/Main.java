import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

public class Main {

    public static void main(String[] args) {

        long inicio = System.currentTimeMillis();

        ResultadoCompartido resultado = new ResultadoCompartido();

        ProcesadorArchivo hilo1 = new ProcesadorArchivo("texto1.txt", resultado);
        ProcesadorArchivo hilo2 = new ProcesadorArchivo("texto2.txt", resultado);
        ProcesadorArchivo hilo3 = new ProcesadorArchivo("texto3.txt", resultado);

        hilo1.start();
        hilo2.start();
        hilo3.start();

        try {
            hilo1.join();
            hilo2.join();
            hilo3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        long fin = System.currentTimeMillis();
        long tiempo = fin - inicio;

        generarReporte(resultado, tiempo);

        System.out.println("Proceso terminado correctamente.");
    }

    private static void generarReporte(ResultadoCompartido resultado, long tiempo) {

        try (FileWriter writer = new FileWriter("estadisticas.txt")) {

            writer.write("========================================\n");
            writer.write("REPORTE DE PROCESAMIENTO DE ARCHIVOS\n");
            writer.write("========================================\n\n");

            for (Map.Entry<String, Integer> entry : resultado.getResultados().entrySet()) {
                writer.write("Archivo: " + entry.getKey() + "\n");
                writer.write("Palabras encontradas: " + entry.getValue() + "\n\n");
            }

            writer.write("----------------------------------------\n");
            writer.write("Total de palabras procesadas: " 
                         + resultado.getTotalPalabras() + "\n");
            writer.write("Tiempo de procesamiento: " + tiempo + " ms\n");
            writer.write("========================================\n");

        } catch (IOException e) {
            System.out.println("Error generando reporte.");
        }
    }
}
